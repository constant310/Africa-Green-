'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { appUrl, supabase } from '@/lib/supabase';

export default function AuthForm({ mode }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);
  const router = useRouter();

  async function google() {
    setBusy(true);
    const { error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: { redirectTo: `${appUrl}/auth/callback?next=/portal` },
    });
    if (error) setMessage(error.message);
    setBusy(false);
  }

  async function submit(event) {
    event.preventDefault();
    setBusy(true);
    setMessage('');

    if (mode === 'login') {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) setMessage(error.message);
      else router.push('/portal');
    } else {
      const { error } = await supabase.auth.signUp({
        email,
        password,
        options: { emailRedirectTo: `${appUrl}/auth/callback?next=/portal` },
      });
      setMessage(error ? error.message : 'Account created. Check your email if verification is required.');
    }

    setBusy(false);
  }

  return (
    <div className="authShell">
      <form className="authCard" onSubmit={submit}>
        <div className="brandMark">AD</div>
        <h1>{mode === 'login' ? 'Welcome back' : 'Create membership account'}</h1>
        <p className="muted">Secure access to the cooperative portal.</p>
        <button type="button" className="btn google" onClick={google} disabled={busy}>Continue with Google</button>
        <div className="divider">or</div>
        <label>Email</label>
        <input value={email} onChange={(e) => setEmail(e.target.value)} type="email" required />
        <label>Password</label>
        <input value={password} onChange={(e) => setPassword(e.target.value)} type="password" minLength={8} required />
        <button className="btn primary" disabled={busy}>{busy ? 'Please wait…' : mode === 'login' ? 'Sign in' : 'Create account'}</button>
        {message && <p className="notice">{message}</p>}
        <p className="muted small">
          {mode === 'login' ? <><a href="/register">New member? Create account</a> · <a href="/forgot-password">Forgot password?</a></> : <a href="/login">Already registered? Sign in</a>}
        </p>
      </form>
    </div>
  );
}

'use client';

import { useState } from 'react';
import { appUrl, supabase } from '@/lib/supabase';

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');

  async function submit(event) {
    event.preventDefault();
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${appUrl}/auth/callback?next=/update-password`,
    });
    setMessage(error ? error.message : 'If the account exists, a password reset email has been sent.');
  }

  return (
    <div className="authShell">
      <form className="authCard" onSubmit={submit}>
        <h1>Reset password</h1>
        <label>Email</label>
        <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
        <button className="btn primary">Send reset link</button>
        {message && <p className="notice">{message}</p>}
        <p><a href="/login">Back to sign in</a></p>
      </form>
    </div>
  );
}

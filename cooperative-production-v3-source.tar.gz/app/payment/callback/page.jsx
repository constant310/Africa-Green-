'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';

export default function PaymentCallbackPage() {
  const router = useRouter();
  useEffect(() => {
    const timer = setTimeout(() => router.replace('/portal'), 1800);
    return () => clearTimeout(timer);
  }, [router]);

  return (
    <div className="centerCard">
      <h2>Payment received</h2>
      <p>Your payment is being verified. Your wallet will update after Paystack confirmation.</p>
    </div>
  );
}

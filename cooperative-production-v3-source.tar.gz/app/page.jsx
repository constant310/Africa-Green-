import Link from 'next/link';

export default function Home() {
  return (
    <main className="landing">
      <section className="hero">
        <div className="heroInner">
          <p className="eyebrow">ACRES OF DIAMOND</p>
          <h1>Multipurpose Cooperative Society</h1>
          <p className="lead">
            Secure membership, savings, shares, loans and withdrawals with controlled approvals and transaction PIN protection.
          </p>
          <div className="heroActions">
            <Link className="btn primary" href="/register">Become a Member</Link>
            <Link className="btn" href="/login">Sign in</Link>
          </div>
        </div>
      </section>
    </main>
  );
}

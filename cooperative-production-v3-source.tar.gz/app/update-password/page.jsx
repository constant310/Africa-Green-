'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { supabase } from '@/lib/supabase';

export default function UpdatePasswordPage() {
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');
  const router = useRouter();

  async function submit(event) {
    event.preventDefault();
    const { error } = await supabase.auth.updateUser({ password });
    if (error) setMessage(error.message);
    else {
      setMessage('Password updated.');
      setTimeout(() => router.replace('/portal'), 500);
    }
  }

  return (
    <div className="authShell">
      <form className="authCard" onSubmit={submit}>
        <h1>Choose a new password</h1>
        <label>New password</label>
        <input type="password" minLength={8} value={password} onChange={(e) => setPassword(e.target.value)} required />
        <button className="btn primary">Update password</button>
        {message && <p className="notice">{message}</p>}
      </form>
    </div>
  );
}

import './globals.css';

export const metadata = {
  title: 'Acres of Diamond Multipurpose Cooperative Society',
  description: 'Secure digital cooperative platform',
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}

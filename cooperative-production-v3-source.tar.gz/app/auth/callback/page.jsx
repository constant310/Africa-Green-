'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { supabase } from '@/lib/supabase';

export default function AuthCallbackPage() {
  const [message, setMessage] = useState('Completing sign in…');
  const router = useRouter();

  useEffect(() => {
    (async () => {
      const url = new URL(window.location.href);
      const code = url.searchParams.get('code');
      const next = url.searchParams.get('next') || '/portal';
      if (code) {
        const { error } = await supabase.auth.exchangeCodeForSession(code);
        if (error) return setMessage(error.message);
      }
      const { data } = await supabase.auth.getSession();
      if (data.session) {
        await supabase.rpc('start_app_session', { p_device_label: navigator.userAgent.slice(0, 100) });
        router.replace(next);
      } else {
        setMessage('No active session was created. Please sign in again.');
      }
    })();
  }, [router]);

  return <div className="centerCard">{message}</div>;
}

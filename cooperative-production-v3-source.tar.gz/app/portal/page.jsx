'use client';

import { useEffect, useMemo, useState } from 'react';
import { useRouter } from 'next/navigation';
import { supabase } from '@/lib/supabase';

const MEMBER_NAV = [
  ['dashboard', 'Dashboard'], ['onboarding', 'Onboarding'], ['wallet', 'Wallet'],
  ['savings', 'Savings'], ['shares', 'Shares'], ['loans', 'Loans'],
  ['guarantees', 'Guarantees'], ['withdrawals', 'Withdrawals'],
  ['transactions', 'Transactions'], ['receipts', 'Receipts'], ['statements', 'Statements'],
  ['security', 'Security & PIN'], ['sessions', 'Sessions'],
];

const money = (value) => `₦${Number(value || 0).toLocaleString('en-NG', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

function Stat({ t, v }) { return <div className="stat"><small>{t}</small><strong>{v}</strong></div>; }
function Detail({ k, v }) { return <div><small>{k}</small><b>{String(v)}</b></div>; }
function Empty() { return <p className="muted">Nothing to show yet.</p>; }
function Field({ label, value, onChange, type = 'text' }) {
  return <label className="field">{label}<input type={type} value={value} onChange={(e) => onChange(e.target.value)} /></label>;
}
function Pin({ pin, setPin, label = 'Transaction PIN' }) {
  return <label className="field">{label}<input type="password" inputMode="numeric" maxLength={4} pattern="[0-9]{4}" value={pin} onChange={(e) => setPin(e.target.value.replace(/\D/g, '').slice(0, 4))} placeholder="••••" /></label>;
}
function QueueRow({ title, sub, approve, reject, disabled }) {
  return <div className="listRow"><div><b>{title}</b><small>{sub}</small></div><div className="row"><button className="btn" disabled={disabled} onClick={reject}>Reject</button><button className="btn primary" disabled={disabled} onClick={approve}>Approve</button></div></div>;
}
function AdminCenter({ admin, call, busy }) {
  if (!admin) return <section className="panel"><Empty /></section>;
  return <section className="panel">
    <h2>Admin control center</h2>
    <p className="muted">Maker-checker rules prevent self-approval and require two distinct reviewers. Privileged writes also require verified MFA.</p>
    <section className="stats">
      <Stat t="Applications" v={String((admin.applications || []).length)} /><Stat t="Loans" v={String((admin.loans || []).length)} />
      <Stat t="Withdrawals" v={String((admin.withdrawals || []).length)} /><Stat t="Admins" v={String((admin.admins || []).length)} />
    </section>
    <h3>Membership queue</h3>
    {(admin.applications || []).map((item) => <QueueRow key={item.user_id} title={`${item.first_name || ''} ${item.last_name || ''}`} sub={`${item.member_id || 'Applicant'} · ${item.status}`} disabled={busy || !item.can_review}
      approve={() => call('review_membership_application', { p_user: item.user_id, p_decision: 'approve', p_note: 'Reviewed in admin portal' })}
      reject={() => call('review_membership_application', { p_user: item.user_id, p_decision: 'reject', p_note: 'Rejected in admin portal' })} />)}
    <h3>Loan queue</h3>
    {(admin.loans || []).map((item) => <QueueRow key={item.id} title={`${item.first_name || ''} ${item.last_name || ''} · ${money(item.amount)}`} sub={item.status} disabled={busy || !item.can_review}
      approve={() => call('review_loan', { p_loan_id: item.id, p_decision: 'approve', p_approved_amount: item.amount, p_note: 'Reviewed in admin portal' })}
      reject={() => call('review_loan', { p_loan_id: item.id, p_decision: 'reject', p_approved_amount: null, p_note: 'Rejected in admin portal' })} />)}
    <h3>Withdrawal queue</h3>
    {(admin.withdrawals || []).map((item) => <QueueRow key={item.id} title={`${item.first_name || ''} ${item.last_name || ''} · ${money(item.amount)}`} sub={`${item.status} · ${item.bank_name}`} disabled={busy || !item.can_review}
      approve={() => call('review_withdrawal', { p_withdrawal_id: item.id, p_decision: 'approve', p_note: 'Reviewed in admin portal' })}
      reject={() => call('review_withdrawal', { p_withdrawal_id: item.id, p_decision: 'reject', p_note: 'Rejected in admin portal' })} />)}
  </section>;
}

const BLANK_FORM = { first_name:'', middle_name:'', last_name:'', phone:'', dob:'', residential_address:'', nationality:'Nigerian', state_of_origin:'', lga:'', occupation:'', employer:'', next_of_kin_name:'', next_of_kin_relationship:'', next_of_kin_phone:'', next_of_kin_address:'' };

export default function PortalPage() {
  const router = useRouter();
  const [section, setSection] = useState('dashboard');
  const [snapshot, setSnapshot] = useState(null);
  const [admin, setAdmin] = useState(null);
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);
  const [pin, setPin] = useState('');
  const [currentPin, setCurrentPin] = useState('');
  const [amount, setAmount] = useState('');
  const [units, setUnits] = useState('1');
  const [scheme, setScheme] = useState('');
  const [selectedLoan, setSelectedLoan] = useState('');
  const [products, setProducts] = useState([]);
  const [product, setProduct] = useState('');
  const [term, setTerm] = useState('6');
  const [purpose, setPurpose] = useState('');
  const [guarantors, setGuarantors] = useState('');
  const [quote, setQuote] = useState(null);
  const [bank, setBank] = useState({ bank_name:'', bank_code:'', account_name:'', account_number:'' });
  const [nin, setNin] = useState('');
  const [passport, setPassport] = useState(null);
  const [statement, setStatement] = useState([]);
  const [form, setForm] = useState(BLANK_FORM);
  const [mfa, setMfa] = useState({ factors:[], factorId:'', qr:'', secret:'', code:'' });

  async function refresh() {
    setMessage('');
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return router.replace('/login');
    await supabase.rpc('start_app_session', { p_device_label: navigator.userAgent.slice(0, 100) });
    const [{ data, error }, { data: loanProducts }] = await Promise.all([
      supabase.rpc('member_complete_snapshot'),
      supabase.from('loan_products').select('*').eq('active', true).order('name'),
    ]);
    if (error) return setMessage(error.message);
    setSnapshot(data); setProducts(loanProducts || []);
    const profile = data?.portal?.profile || {};
    setForm((old) => ({ ...old, first_name:profile.first_name||old.first_name, middle_name:profile.other_name||old.middle_name, last_name:profile.last_name||old.last_name, phone:profile.phone||old.phone, dob:profile.dob||old.dob, residential_address:profile.address||old.residential_address, occupation:profile.occupation||old.occupation, employer:profile.employer||old.employer }));
    if (['admin','super_admin'].includes(profile.role)) {
      const res = await supabase.rpc('admin_control_center_snapshot');
      if (!res.error) setAdmin(res.data);
    }
  }

  useEffect(() => {
    refresh();
    const timer = setInterval(() => supabase.rpc('touch_app_session'), 120000);
    return () => clearInterval(timer);
  }, []);

  const portal = snapshot?.portal || {};
  const profile = portal.profile || {};
  const savingsSchemes = portal.savings_schemes || [];
  const recentTransactions = portal.recent_transactions || [];
  const withdrawals = portal.withdrawals || [];
  const loans = portal.loans || [];
  const receipts = snapshot?.receipts || [];
  const pinStatus = portal.pin_status || {};
  const role = profile.role || 'member';
  const nav = useMemo(() => ['admin','super_admin'].includes(role) ? [...MEMBER_NAV, ['admin','Admin Control'], ['mfa','Admin MFA']] : MEMBER_NAV, [role]);
  const title = useMemo(() => nav.find((x) => x[0] === section)?.[1] || 'Dashboard', [section, nav]);

  async function call(name, args = {}) {
    setBusy(true); setMessage('');
    const { data, error } = await supabase.rpc(name, args);
    if (error) setMessage(error.message);
    else if (data?.ok === false) setMessage(data.error || 'Action could not be completed');
    else { setMessage('Done successfully.'); setPin(''); await refresh(); }
    setBusy(false);
    return { data, error };
  }
  async function signOut() { await supabase.rpc('end_app_session', { p_reason:'user_logout' }); await supabase.auth.signOut(); router.replace('/login'); }
  async function saveRegistration() { await call('save_registration_form', { p_form:{ ...form, next_of_kin:{ name:form.next_of_kin_name, relationship:form.next_of_kin_relationship, phone:form.next_of_kin_phone, address:form.next_of_kin_address } } }); }
  async function uploadPassport() {
    if (!passport) return setMessage('Choose a passport photograph first.');
    setBusy(true); setMessage('');
    const { data:{ user } } = await supabase.auth.getUser();
    if (!user) { setBusy(false); return setMessage('Sign in again.'); }
    if (passport.size > 5242880) { setBusy(false); return setMessage('Passport image must be 5 MB or less.'); }
    const ext=(passport.name.split('.').pop()||'jpg').toLowerCase(); const path=`${user.id}/passport-${Date.now()}.${ext}`;
    const up=await supabase.storage.from('kyc-private').upload(path,passport,{contentType:passport.type||'image/jpeg',upsert:false});
    if (up.error) { setBusy(false); return setMessage(up.error.message); }
    const insert=await supabase.from('kyc_documents').insert({user_id:user.id,document_type:'passport_photo',storage_path:path,status:'submitted'});
    if (insert.error) { setBusy(false); return setMessage(insert.error.message); }
    setBusy(false); setMessage('Passport photograph submitted.'); await refresh();
  }
  async function getQuote() {
    if (!product || !amount) return setMessage('Select a loan product and amount.');
    setBusy(true); const { data,error }=await supabase.rpc('loan_quote',{p_product:product,p_amount:Number(amount),p_term_months:Number(term)}); setBusy(false); error?setMessage(error.message):setQuote(data);
  }
  async function submitLoan() { await call('submit_loan_by_member_ids',{p_product:product,p_amount:Number(amount),p_term_months:Number(term),p_purpose:purpose,p_guarantor_member_ids:guarantors.split(',').map(x=>x.trim()).filter(Boolean)}); }
  async function loadStatement() { const from=new Date(); from.setDate(from.getDate()-90); setBusy(true); const {data,error}=await supabase.rpc('member_statement',{p_from:from.toISOString().slice(0,10),p_to:new Date().toISOString().slice(0,10)}); setBusy(false); error?setMessage(error.message):setStatement(Array.isArray(data)?data:data?.items||data?.transactions||[]); }
  async function listFactors() { const {data,error}=await supabase.auth.mfa.listFactors(); error?setMessage(error.message):setMfa(x=>({...x,factors:data?.totp||[]})); }
  async function enrollMfa() { setBusy(true); const {data,error}=await supabase.auth.mfa.enroll({factorType:'totp',friendlyName:'Acres Admin'}); setBusy(false); error?setMessage(error.message):setMfa(x=>({...x,factorId:data.id,qr:data.totp.qr_code,secret:data.totp.secret})); }
  async function verifyMfa() {
    if (!mfa.factorId || !mfa.code) return;
    setBusy(true); const challenge=await supabase.auth.mfa.challenge({factorId:mfa.factorId});
    if (challenge.error) { setBusy(false); return setMessage(challenge.error.message); }
    const result=await supabase.auth.mfa.verify({factorId:mfa.factorId,challengeId:challenge.data.id,code:mfa.code}); setBusy(false); setMessage(result.error?result.error.message:'MFA verified. Privileged admin actions are unlocked for this session.'); await listFactors();
  }

  return <div className="appShell">
    <aside className="sidebar">
      <div className="sideBrand"><span>AD</span><div>Acres of Diamond<small>Multipurpose Cooperative Society</small></div></div>
      <nav>{nav.map(([key,label]) => <button key={key} className={section===key?'active':''} onClick={()=>{setSection(key); if(key==='mfa') listFactors();}}>{label}</button>)}</nav>
      <button className="logout" onClick={signOut}>Sign out</button>
    </aside>
    <main className="content">
      <header className="topbar"><div><p className="eyebrow">MEMBER PORTAL</p><h1>{title}</h1></div><div className="profilePill">{profile.first_name||'Member'} · {profile.member_id||role}</div></header>
      {message && <div className="alert">{message}</div>}

      {section==='dashboard' && <><section className="stats"><Stat t="Wallet" v={money(portal.wallet_balance)} /><Stat t="Savings" v={money(portal.total_contributions)} /><Stat t="Share capital" v={money(portal.share_capital)} /><Stat t="Outstanding loans" v={money(portal.outstanding_loans)} /></section><section className="panel"><h2>Account status</h2><div className="detailGrid"><Detail k="Member status" v={profile.status||'—'} /><Detail k="Role" v={role} /><Detail k="Transaction PIN" v={pinStatus.pin_set?'Set':'Not set'} /><Detail k="Pledged security" v={money(portal.pledged_security)} /></div></section></>}

      {section==='onboarding' && <section className="panel"><h2>Membership onboarding</h2><p className="muted">Complete each step. Registration fee and share purchases require your transaction PIN because they debit your wallet.</p><div className="detailGrid"><Detail k="Application" v={snapshot?.onboarding?.status?.application_status||snapshot?.onboarding?.application?.status||'draft'} /><Detail k="NIN" v={snapshot?.onboarding?.status?.nin_status||'not submitted'} /><Detail k="Bye-laws" v={snapshot?.onboarding?.status?.bylaws_accepted?'Accepted':'Not accepted'} /><Detail k="Registration fee" v={snapshot?.onboarding?.status?.registration_fee_paid?'Paid':'Not paid'} /></div>
        <div className="actionBox"><h3>1. Registration form</h3><div className="twoCol">{Object.entries({first_name:'First name',middle_name:'Middle name',last_name:'Last name',phone:'Phone',dob:'Date of birth',residential_address:'Residential address',nationality:'Nationality',state_of_origin:'State of origin',lga:'LGA',occupation:'Occupation',employer:'Employer / business',next_of_kin_name:'Next of kin',next_of_kin_relationship:'Relationship',next_of_kin_phone:'Next-of-kin phone',next_of_kin_address:'Next-of-kin address'}).map(([key,label])=><Field key={key} label={label} type={key==='dob'?'date':'text'} value={form[key]} onChange={(value)=>setForm(x=>({...x,[key]:value}))} />)}</div><button className="btn primary" disabled={busy} onClick={saveRegistration}>Save registration form</button></div>
        <div className="actionBox"><h3>2. Submit NIN</h3><Field label="11-digit NIN" value={nin} onChange={(v)=>setNin(v.replace(/\D/g,'').slice(0,11))} /><button className="btn primary" disabled={busy||nin.length!==11} onClick={()=>call('submit_member_nin',{p_nin:nin})}>Submit NIN</button></div>
        <div className="actionBox"><h3>3. Passport photograph</h3><input type="file" accept="image/jpeg,image/png,image/webp" onChange={(e)=>setPassport(e.target.files?.[0]||null)} /><button className="btn primary" disabled={busy||!passport} onClick={uploadPassport}>Upload passport</button></div>
        <div className="actionBox"><h3>4. Bye-laws</h3>{snapshot?.onboarding?.current_bylaws?.file_url&&<p><a target="_blank" rel="noreferrer" href={snapshot.onboarding.current_bylaws.file_url}>Open current bye-laws</a></p>}<button className="btn primary" disabled={busy} onClick={()=>call('accept_current_bylaws')}>I have read and accept the current bye-laws</button></div>
        <div className="actionBox"><h3>5. Registration fee</h3><p className="muted">Transaction PIN required.</p><Pin pin={pin} setPin={setPin}/><button className="btn primary" disabled={busy||pin.length!==4} onClick={()=>call('pay_registration_fee',{p_pin:pin})}>Pay registration fee from wallet</button></div>
        <div className="actionBox"><h3>6. Minimum share capital</h3><Field label="Share units" value={units} onChange={setUnits}/><Pin pin={pin} setPin={setPin}/><button className="btn primary" disabled={busy||pin.length!==4} onClick={()=>call('buy_shares',{p_units:Number(units),p_pin:pin})}>Buy shares from wallet</button></div>
        <div className="actionBox"><h3>7. Final submission</h3><p className="muted">Your application will enter the two-reviewer approval workflow.</p><button className="btn primary" disabled={busy} onClick={()=>call('submit_membership_application')}>Submit membership application</button></div>
      </section>}

      {section==='wallet' && <section className="panel"><h2>Wallet</h2><div className="bigBalance">{money(portal.wallet_balance)}</div><p className="muted">Funding adds money to your wallet and does not require a transaction PIN. Spending from the wallet does.</p><div className="actionBox"><h3>Fund wallet with Paystack</h3><Field label="Amount" value={amount} onChange={setAmount}/><button className="btn primary" disabled={busy||Number(amount)<100} onClick={async()=>{setBusy(true);const {data,error}=await supabase.rpc('paystack_initialize',{p_amount:Number(amount)});setBusy(false);error?setMessage(error.message):data?.authorization_url&&(window.location.href=data.authorization_url);}}>Continue to Paystack</button></div></section>}

      {section==='savings' && <section className="panel"><h2>Savings</h2><p className="muted">Choose a scheme and save any amount permitted by its policy. Wallet debit requires your PIN.</p><div className="actionBox"><label>Scheme</label><select value={scheme} onChange={(e)=>setScheme(e.target.value)}><option value="">Select scheme</option>{savingsSchemes.map((x)=><option value={x.id} key={x.id}>{x.name} {x.minimum_contribution?`— min ${money(x.minimum_contribution)}`:''}</option>)}</select><Field label="Amount" value={amount} onChange={setAmount}/><Pin pin={pin} setPin={setPin}/><button className="btn primary" disabled={busy||!scheme||pin.length!==4} onClick={()=>call('save_to_scheme',{p_scheme:scheme,p_amount:Number(amount),p_pin:pin})}>Save from wallet</button></div></section>}

      {section==='shares' && <section className="panel"><h2>Share capital</h2><div className="bigBalance">{money(portal.share_capital)}</div><div className="actionBox"><Field label="Units" value={units} onChange={setUnits}/><Pin pin={pin} setPin={setPin}/><button className="btn primary" disabled={busy||pin.length!==4} onClick={()=>call('buy_shares',{p_units:Number(units),p_pin:pin})}>Buy shares from wallet</button></div></section>}

      {section==='loans' && <section className="panel"><h2>Loans</h2><div className="actionBox"><h3>Apply for a loan</h3><label>Loan product</label><select value={product} onChange={(e)=>setProduct(e.target.value)}><option value="">Select product</option>{products.map((x)=><option value={x.id} key={x.id}>{x.name}</option>)}</select><div className="twoCol"><Field label="Amount" value={amount} onChange={setAmount}/><Field label="Term (months)" value={term} onChange={setTerm}/></div><Field label="Purpose" value={purpose} onChange={setPurpose}/><Field label="Guarantor Member IDs (comma separated, max 2)" value={guarantors} onChange={setGuarantors}/><div className="row left"><button className="btn" disabled={busy} onClick={getQuote}>Get quote</button><button className="btn primary" disabled={busy||!product} onClick={submitLoan}>Submit loan application</button></div>{quote&&<div className="quote"><Detail k="Total interest" v={money(quote.total_interest)}/><Detail k="Total payable" v={money(quote.total_payable)}/><Detail k="Available security" v={money(quote.available_security)}/><Detail k="Eligible by tenure" v={quote.eligible_by_tenure?'Yes':'No'}/></div>}</div><h3>My loans</h3>{loans.length?loans.map((x)=><div className="listRow" key={x.id}><div><b>{money(x.amount)}</b><small>{x.status} · {x.term_months} months · outstanding {money(x.outstanding)}</small></div>{['disbursed','repaying'].includes(x.status)&&<button className="btn" onClick={()=>setSelectedLoan(x.id)}>Repay</button>}</div>):<Empty/>}{selectedLoan&&<div className="actionBox"><h3>Repay selected loan</h3><Field label="Amount" value={amount} onChange={setAmount}/><Pin pin={pin} setPin={setPin}/><button className="btn primary" disabled={busy||pin.length!==4} onClick={()=>call('repay_loan',{p_loan:selectedLoan,p_amount:Number(amount),p_pin:pin})}>Repay from wallet</button></div>}</section>}

      {section==='guarantees' && <section className="panel"><h2>Guarantee requests</h2>{(portal.guarantee_requests||[]).map((x)=><div className="listRow" key={x.loan_id}><div><b>{x.borrower_name}</b><small>{money(x.amount)} · pledge {money(x.pledged_amount)} · {x.status}</small></div>{x.status==='pending'&&<div className="row"><button className="btn" onClick={()=>call('respond_to_guarantee',{p_loan:x.loan_id,p_accept:false})}>Decline</button><button className="btn primary" onClick={()=>call('respond_to_guarantee',{p_loan:x.loan_id,p_accept:true})}>Accept</button></div>}</div>)}{!(portal.guarantee_requests||[]).length&&<Empty/>}</section>}

      {section==='withdrawals' && <section className="panel"><h2>Withdraw to bank</h2><div className="actionBox"><Field label="Amount" value={amount} onChange={setAmount}/><Field label="Bank name" value={bank.bank_name} onChange={(v)=>setBank({...bank,bank_name:v})}/><Field label="Bank code" value={bank.bank_code} onChange={(v)=>setBank({...bank,bank_code:v})}/><Field label="Account name" value={bank.account_name} onChange={(v)=>setBank({...bank,account_name:v})}/><Field label="10-digit account number" value={bank.account_number} onChange={(v)=>setBank({...bank,account_number:v.replace(/\D/g,'').slice(0,10)})}/><Pin pin={pin} setPin={setPin}/><button className="btn primary" disabled={busy||pin.length!==4||bank.account_number.length!==10} onClick={()=>call('request_withdrawal_v2',{p_amount:Number(amount),p_bank_name:bank.bank_name,p_bank_code:bank.bank_code,p_account_name:bank.account_name,p_account_number:bank.account_number,p_pin:pin})}>Request withdrawal</button></div>{withdrawals.map((x)=><div className="listRow" key={x.id}><div><b>{money(x.amount)}</b><small>{x.status} · {x.bank_name} · fee {money(x.fee_amount)}</small></div></div>)}</section>}

      {section==='transactions' && <section className="panel"><h2>Recent transactions</h2>{recentTransactions.map((x)=><div className="listRow" key={x.id}><div><b>{x.description||x.type}</b><small>{x.reference} · {new Date(x.created_at).toLocaleString()}</small></div><strong>{money(x.amount)}</strong></div>)}{!recentTransactions.length&&<Empty/>}<p className="muted small">Use Statements for a longer transaction period.</p></section>}
      {section==='receipts' && <section className="panel"><h2>Receipts</h2>{receipts.map((x)=><div className="listRow" key={x.id}><div><b>{x.receipt_number||x.reference||'Receipt'}</b><small>{new Date(x.issued_at).toLocaleDateString()}</small></div></div>)}{!receipts.length&&<Empty/>}</section>}
      {section==='statements' && <section className="panel"><h2>Statements</h2><p className="muted">Load the last 90 days of your cooperative statement.</p><button className="btn primary" disabled={busy} onClick={loadStatement}>Load 90-day statement</button>{statement.map((x,i)=><div className="listRow" key={x.id||i}><div><b>{x.description||x.type||'Transaction'}</b><small>{x.reference||''} {x.created_at?`· ${new Date(x.created_at).toLocaleString()}`:''}</small></div><strong>{x.amount!=null?money(x.amount):''}</strong></div>)}</section>}

      {section==='security' && <section className="panel"><h2>Transaction PIN</h2><p className="muted">Required for every member-initiated wallet debit. Five failed attempts temporarily lock the PIN.</p><div className="detailGrid"><Detail k="PIN status" v={pinStatus.pin_set?'Set':'Not set'}/><Detail k="Locked" v={pinStatus.locked?'Yes':'No'}/></div><div className="actionBox">{pinStatus.pin_set&&<Pin pin={currentPin} setPin={setCurrentPin} label="Current PIN"/>}<Pin pin={pin} setPin={setPin} label={pinStatus.pin_set?'New 4-digit PIN':'Create 4-digit PIN'}/><button className="btn primary" disabled={busy||pin.length!==4||(pinStatus.pin_set&&currentPin.length!==4)} onClick={()=>call('set_transaction_pin',{p_new_pin:pin,p_current_pin:pinStatus.pin_set?currentPin:null})}>{pinStatus.pin_set?'Change PIN':'Set PIN'}</button></div></section>}
      {section==='sessions' && <section className="panel"><h2>Sessions</h2><p className="muted">Your app session is refreshed securely in the background.</p><button className="btn" onClick={()=>call('revoke_other_app_sessions')}>Sign out other sessions</button></section>}
      {section==='admin' && <AdminCenter admin={admin} call={call} busy={busy}/>} 
      {section==='mfa' && <section className="panel"><h2>Admin MFA</h2><p className="muted">Admin and Super Admin write actions require TOTP MFA (AAL2).</p><button className="btn" onClick={listFactors}>Refresh factors</button>{(mfa.factors||[]).map((factor)=><div className="listRow" key={factor.id}><div><b>{factor.friendly_name||'Authenticator'}</b><small>{factor.status}</small></div><button className="btn" onClick={()=>setMfa(x=>({...x,factorId:factor.id,qr:'',secret:''}))}>Use this factor</button></div>)}<div className="actionBox"><button className="btn primary" disabled={busy} onClick={enrollMfa}>Enroll new authenticator</button>{mfa.qr&&<><img className="qr" src={mfa.qr} alt="MFA QR code"/><p className="small">Manual secret: <code>{mfa.secret}</code></p></>}<Field label="6-digit authenticator code" value={mfa.code||''} onChange={(v)=>setMfa(x=>({...x,code:v.replace(/\D/g,'').slice(0,6)}))}/><button className="btn primary" disabled={busy||!mfa.factorId||(mfa.code||'').length!==6} onClick={verifyMfa}>Verify MFA</button></div></section>}
    </main>
  </div>;
}

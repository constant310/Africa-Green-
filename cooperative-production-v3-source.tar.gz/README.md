# Acres of Diamond Cooperative — V3

Readable source recovery of the current `cooperative-production-v3.vercel.app` production frontend.

## Stack
- Next.js 16 App Router
- React 19
- Supabase Auth / Postgres RPC / Storage
- Google OAuth through Supabase
- Paystack initialization through Supabase RPC
- TOTP MFA for privileged admin actions

## Run locally
```bash
npm install
npm run dev
```

The Supabase URL and publishable client key can be supplied through `.env.local` using `.env.example`.

## Production routes
`/`, `/login`, `/register`, `/forgot-password`, `/update-password`, `/auth/callback`, `/payment/callback`, `/portal`.

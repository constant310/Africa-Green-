# Acres of Diamond Multipurpose Cooperative Society
Full test-mode cooperative portal built with Next.js 15, TypeScript, Tailwind and Supabase.

## Test integrations
- Paystack test mode: real test API credentials kept in Supabase Vault, never client-side.
- Smile ID: sandbox/dummy adapter until production credentials are supplied.
- SMS: opt-in preferences with charge consent; provider adapter pending chosen provider.

## Run
1. Copy `.env.example` to `.env.local` and insert the Supabase publishable key.
2. `npm install`
3. `npm run dev`

## Production switch
Only switch Paystack/Smile settings to live after production credentials, webhook verification, KYC callbacks and full UAT/security tests are complete.

# Direct Vercel Deployment

This package is prepared to deploy directly to Vercel without GitHub.

## Windows - easiest route

1. Extract this ZIP.
2. Open the extracted folder.
3. Double-click `deploy-vercel.cmd`.
4. Complete the browser sign-in when Vercel opens it.
5. When asked to link the folder, select your existing Vercel project or create a new one.
6. The script deploys to production and prints the live URL.

## Terminal route

```bash
npx --yes vercel@latest login
npx --yes vercel@latest link
npx --yes vercel@latest --prod
```

## Supabase

The app supports these environment variables:

- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY`

The currently configured public Supabase URL/publishable key are retained as fallbacks so a missing Vercel environment-variable entry does not block the first deployment. Public/publishable browser keys are not service-role secrets. Never put a Supabase service-role key in a `NEXT_PUBLIC_*` variable.

## If Vercel reports a build error

Copy the complete Vercel build error/log into ChatGPT. The source package itself has already passed a TypeScript/TSX syntax scan across all app files.

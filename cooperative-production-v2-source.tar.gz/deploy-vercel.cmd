@echo off
setlocal
cd /d "%~dp0"
echo.
echo Acres of Diamond - Direct Vercel Deployment
echo This route does NOT require GitHub.
echo.
where node >nul 2>nul || (echo ERROR: Node.js is not installed. Install Node.js LTS first.& pause & exit /b 1)
where npm >nul 2>nul || (echo ERROR: npm is not available.& pause & exit /b 1)

echo [1/3] Signing in to Vercel...
call npx --yes vercel@latest login
if errorlevel 1 goto :fail

echo.
echo [2/3] Linking this folder to a Vercel project...
echo If asked whether to link to an existing project, choose N to create a new one,
echo or choose Y and select your existing Acres of Diamond project.
call npx --yes vercel@latest link
if errorlevel 1 goto :fail

echo.
echo [3/3] Deploying to production...
call npx --yes vercel@latest --prod
if errorlevel 1 goto :fail

echo.
echo SUCCESS: Vercel printed your production URL above.
pause
exit /b 0

:fail
echo.
echo Deployment stopped because a command failed. Copy the error shown above into ChatGPT so it can be fixed.
pause
exit /b 1

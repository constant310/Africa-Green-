import Shell from './Shell';import AuthGate from './AuthGate';export default function Protected({children}:{children:React.ReactNode}){return <AuthGate><Shell>{children}</Shell></AuthGate>}

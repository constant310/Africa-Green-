export const money=(n:any)=>`₦${Number(n||0).toLocaleString('en-NG',{maximumFractionDigits:2})}`;
export const pretty=(s:any)=>String(s??'').replaceAll('_',' ').replace(/\b\w/g,c=>c.toUpperCase());
export const msg=(e:any,ok:string)=>e?.message||ok;
